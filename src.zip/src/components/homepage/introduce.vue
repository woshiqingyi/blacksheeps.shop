<template>
  <div class="introduce_layout">
    <div class="introduce_style">
      <div class="mini_navigation"></div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.introduce_layout {
  display: flex;
  justify-content: center;
}

.introduce_style {
  /* border: 1px gray solid;
  height: 700px; */
  width: 1300px;
  margin-top: 20px;
}
.mini_navigation {
  width: 100%;
  height: 800px;
  background-color: whitesmoke;
  /* border: 1px rgb(212, 212, 212) solid; */
}
</style>
