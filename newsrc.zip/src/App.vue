<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>

.c_main_title{
  font-weight:600;
  font-size: 20px;
}
.c_button{
  color: white;
  background-color: #3e86ca;
}

.c_text_button{
  font-size: 12px;
  color: #3e86ca;
}


</style>
